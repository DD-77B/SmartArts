package ru.den.smartarts;

import android.Manifest;
import android.app.Activity;
import android.app.Notification;
import android.app.NotificationManager;
import android.content.ActivityNotFoundException;
import android.content.ClipData;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.util.Base64;
import android.view.View;
import android.view.Window;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.core.content.FileProvider;
import androidx.webkit.WebViewAssetLoader;

import org.json.JSONObject;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.io.ByteArrayOutputStream;
import java.util.Iterator;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class MainActivity extends Activity {

    private static final String START_URL = "https://appassets.androidplatform.net/assets/index.html";
    private static final String AUTHORITY = "ru.den.smartarts.files";
    private static final int REQ_FILE = 11;
    private static final int REQ_CAMERA = 12;

    private WebView web;
    private ValueCallback<Uri[]> fileCallback;
    private Uri cameraUri;
    private PermissionRequest pendingWebPermission;
    private Intent pendingChooser;
    private TextToSpeech tts;
    private boolean ttsReady = false;
    private final Map<String, FileOutputStream> openFiles = new HashMap<>();
    private final Map<String, File> fileTargets = new HashMap<>();
    private final Map<String, String> fileMimes = new HashMap<>();
    private int fileSeq = 0;
    private boolean visible = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        web = new WebView(this);
        setContentView(web);
        WebView.setWebContentsDebuggingEnabled(false);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(true);
        s.setSupportMultipleWindows(true);
        s.setJavaScriptCanOpenWindowsAutomatically(true);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        s.setTextZoom(100);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);

        final WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();

        web.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return loader.shouldInterceptRequest(request.getUrl());
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                if ("appassets.androidplatform.net".equals(u.getHost())) return false;
                openExternal(u.toString());
                return true;
            }
        });

        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                try {
                    launchChooser(params);
                } catch (Exception e) {
                    fileCallback = null;
                    toast("Не удалось открыть выбор файла");
                    return false;
                }
                return true;
            }

            @Override
            public void onPermissionRequest(final PermissionRequest request) {
                runOnUiThread(() -> {
                    boolean wantsCamera = false;
                    for (String r : request.getResources()) {
                        if (PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(r)) wantsCamera = true;
                    }
                    if (!wantsCamera) { request.deny(); return; }
                    if (hasCamera()) {
                        request.grant(new String[]{PermissionRequest.RESOURCE_VIDEO_CAPTURE});
                    } else {
                        pendingWebPermission = request;
                        requestPermissions(new String[]{Manifest.permission.CAMERA}, REQ_CAMERA);
                    }
                });
            }

            @Override
            public boolean onCreateWindow(WebView view, boolean isDialog, boolean isUserGesture, android.os.Message resultMsg) {
                WebView tmp = new WebView(MainActivity.this);
                tmp.setWebViewClient(new WebViewClient() {
                    boolean done = false;
                    @Override
                    public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                        if (!done) { done = true; openExternal(r.getUrl().toString()); }
                        v.destroy();
                        return true;
                    }
                    @Override
                    public void onPageStarted(WebView v, String url, android.graphics.Bitmap favicon) {
                        if (!done && url != null && !url.startsWith("about:")) { done = true; openExternal(url); v.stopLoading(); }
                    }
                });
                WebView.WebViewTransport transport = (WebView.WebViewTransport) resultMsg.obj;
                transport.setWebView(tmp);
                resultMsg.sendToTarget();
                return true;
            }
        });

        web.addJavascriptInterface(new Bridge(), "AndroidBridge");

        tts = new TextToSpeech(this, status -> {
            if (status == TextToSpeech.SUCCESS) {
                int r = tts.setLanguage(new Locale("ru", "RU"));
                ttsReady = r != TextToSpeech.LANG_MISSING_DATA && r != TextToSpeech.LANG_NOT_SUPPORTED;
                if (!ttsReady) ttsReady = true;
                tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                    @Override public void onStart(String id) {}
                    @Override public void onDone(String id) { js("window.__ttsDone&&window.__ttsDone(" + JSONObject.quote(id) + ")"); }
                    @Override public void onError(String id) { js("window.__ttsDone&&window.__ttsDone(" + JSONObject.quote(id) + ")"); }
                    @Override public void onRangeStart(String id, int start, int end, int frame) {
                        js("window.__ttsRange&&window.__ttsRange(" + JSONObject.quote(id) + "," + start + ")");
                    }
                });
            }
        });

        if (savedInstanceState != null) web.restoreState(savedInstanceState);
        else {
            String op = getIntent() != null ? getIntent().getStringExtra("open") : null;
            web.loadUrl(op != null && op.startsWith("/assets/") ? "https://appassets.androidplatform.net" + op : START_URL);
        }
    }

    // ---------- Выбор файлов и камера ----------
    private void launchChooser(WebChromeClient.FileChooserParams params) {
        List<String> mimes = new ArrayList<>();
        boolean anyExt = false;
        for (String t : params.getAcceptTypes()) {
            if (t == null) continue;
            for (String p : t.split(",")) {
                p = p.trim().toLowerCase(Locale.ROOT);
                if (p.isEmpty()) continue;
                if (p.startsWith(".")) {
                    anyExt = true;
                    if (p.equals(".json")) mimes.add("application/json");
                    else if (p.equals(".html") || p.equals(".htm")) mimes.add("text/html");
                    else if (p.equals(".pdf")) mimes.add("application/pdf");
                } else mimes.add(p);
            }
        }
        boolean multiple = params.getMode() == WebChromeClient.FileChooserParams.MODE_OPEN_MULTIPLE;
        boolean images = false, videos = false;
        for (String m : mimes) { if (m.startsWith("image/")) images = true; if (m.startsWith("video/")) videos = true; }

        Intent pick = new Intent(Intent.ACTION_GET_CONTENT);
        pick.addCategory(Intent.CATEGORY_OPENABLE);
        if (anyExt || mimes.isEmpty()) pick.setType("*/*");
        else if (mimes.size() == 1) pick.setType(mimes.get(0));
        else { pick.setType("*/*"); pick.putExtra(Intent.EXTRA_MIME_TYPES, mimes.toArray(new String[0])); }
        pick.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, multiple);

        Intent chooser = Intent.createChooser(pick, "Выберите файл");
        List<Intent> extra = new ArrayList<>();
        cameraUri = null;
        if ((images || videos) && hasCamera()) {
            try {
                File dir = new File(getCacheDir(), "camera");
                dir.mkdirs();
                if (images) {
                    File f = new File(dir, "photo_" + System.currentTimeMillis() + ".jpg");
                    cameraUri = FileProvider.getUriForFile(this, AUTHORITY, f);
                    Intent cam = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                    cam.putExtra(MediaStore.EXTRA_OUTPUT, cameraUri);
                    cam.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    extra.add(cam);
                }
                if (videos) extra.add(new Intent(MediaStore.ACTION_VIDEO_CAPTURE));
            } catch (Exception ignored) {}
        }
        if (!extra.isEmpty()) chooser.putExtra(Intent.EXTRA_INITIAL_INTENTS, extra.toArray(new Intent[0]));
        if ((images || videos) && !hasCamera() && Build.VERSION.SDK_INT >= 23) {
            pendingChooser = chooser;
            requestPermissions(new String[]{Manifest.permission.CAMERA}, REQ_CAMERA);
            return;
        }
        startActivityForResult(chooser, REQ_FILE);
    }

    private boolean hasCamera() {
        return checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode != REQ_CAMERA) return;
        boolean ok = grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED;
        if (pendingWebPermission != null) {
            if (ok) pendingWebPermission.grant(new String[]{PermissionRequest.RESOURCE_VIDEO_CAPTURE});
            else pendingWebPermission.deny();
            pendingWebPermission = null;
        }
        if (pendingChooser != null) {
            Intent c = pendingChooser;
            pendingChooser = null;
            if (ok) {
                // пересобрать выбор уже с камерой
                try {
                    File dir = new File(getCacheDir(), "camera");
                    dir.mkdirs();
                    File f = new File(dir, "photo_" + System.currentTimeMillis() + ".jpg");
                    cameraUri = FileProvider.getUriForFile(this, AUTHORITY, f);
                    Intent cam = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                    cam.putExtra(MediaStore.EXTRA_OUTPUT, cameraUri);
                    cam.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    c.putExtra(Intent.EXTRA_INITIAL_INTENTS, new Intent[]{cam});
                } catch (Exception ignored) {}
            }
            try { startActivityForResult(c, REQ_FILE); }
            catch (Exception e) { if (fileCallback != null) { fileCallback.onReceiveValue(null); fileCallback = null; } }
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQ_FILE || fileCallback == null) return;
        Uri[] result = null;
        if (resultCode == RESULT_OK) {
            List<Uri> uris = new ArrayList<>();
            if (data != null) {
                ClipData clip = data.getClipData();
                if (clip != null) for (int i = 0; i < clip.getItemCount(); i++) uris.add(clip.getItemAt(i).getUri());
                else if (data.getData() != null) uris.add(data.getData());
            }
            if (uris.isEmpty() && cameraUri != null) uris.add(cameraUri);
            if (!uris.isEmpty()) result = uris.toArray(new Uri[0]);
        }
        fileCallback.onReceiveValue(result);
        fileCallback = null;
    }

    // ---------- Кнопка «Назад» ----------
    @Override
    public void onBackPressed() {
        web.evaluateJavascript("(window.androidBack&&window.androidBack())?'1':'0'", v -> {
            if (v == null || !v.contains("1")) MainActivity.super.onBackPressed();
        });
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        web.saveState(outState);
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        String op = intent != null ? intent.getStringExtra("open") : null;
        if (op != null && op.startsWith("/assets/") && web != null) web.loadUrl("https://appassets.androidplatform.net" + op);
    }

    @Override
    protected void onResume() {
        super.onResume();
        visible = true;
        js("window.__appVisible&&window.__appVisible(true)");
    }

    @Override
    protected void onPause() {
        visible = false;
        js("window.__appVisible&&window.__appVisible(false)");
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        try { stopService(new Intent(this, BgService.class)); } catch (Exception ignored) {}
        if (tts != null) { tts.stop(); tts.shutdown(); }
        super.onDestroy();
    }

    // ---------- Вспомогательное ----------
    private void js(final String code) {
        runOnUiThread(() -> web.evaluateJavascript(code, null));
    }

    private void toast(final String t) {
        runOnUiThread(() -> Toast.makeText(MainActivity.this, t, Toast.LENGTH_LONG).show());
    }

    private void openExternal(final String url) {
        runOnUiThread(() -> {
            try {
                Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(i);
            } catch (ActivityNotFoundException e) {
                Toast.makeText(MainActivity.this, "Нет приложения, чтобы открыть ссылку", Toast.LENGTH_LONG).show();
            }
        });
    }

    private static String safeName(String n) {
        if (n == null || n.isEmpty()) n = "file";
        return n.replaceAll("[\\\\/:*?\"<>|]+", "_");
    }

    private Uri saveToDownloads(File src, String name, String mime) throws Exception {
        if (Build.VERSION.SDK_INT >= 29) {
            ContentValues cv = new ContentValues();
            cv.put(MediaStore.Downloads.DISPLAY_NAME, name);
            cv.put(MediaStore.Downloads.MIME_TYPE, mime);
            cv.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/SmartArts");
            Uri uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv);
            if (uri == null) throw new Exception("no uri");
            try (OutputStream out = getContentResolver().openOutputStream(uri); InputStream in = new java.io.FileInputStream(src)) {
                byte[] buf = new byte[65536]; int n;
                while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            }
            return uri;
        } else {
            File dir = getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS);
            if (dir != null) dir.mkdirs();
            File dst = new File(dir, name);
            try (InputStream in = new java.io.FileInputStream(src); OutputStream out = new FileOutputStream(dst)) {
                byte[] buf = new byte[65536]; int n;
                while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            }
            return Uri.fromFile(dst);
        }
    }

    // ---------- Мост JavaScript ↔ Android ----------
    private class Bridge {
        @JavascriptInterface
        public void openUrl(String url) { openExternal(url); }

        @JavascriptInterface
        public void shareText(final String text) {
            runOnUiThread(() -> {
                Intent i = new Intent(Intent.ACTION_SEND);
                i.setType("text/plain");
                i.putExtra(Intent.EXTRA_TEXT, text);
                startActivity(Intent.createChooser(i, "Поделиться"));
            });
        }

        @JavascriptInterface
        public synchronized String fileBegin(String name, String mime) {
            try {
                String id = "f" + (++fileSeq);
                File dir = new File(getCacheDir(), "shared");
                dir.mkdirs();
                File f = new File(dir, safeName(name));
                openFiles.put(id, new FileOutputStream(f));
                fileTargets.put(id, f);
                fileMimes.put(id, (mime == null || mime.isEmpty()) ? "application/octet-stream" : mime);
                return id;
            } catch (Exception e) {
                return "";
            }
        }

        @JavascriptInterface
        public synchronized void fileChunk(String id, String b64) {
            try {
                FileOutputStream out = openFiles.get(id);
                if (out != null) out.write(Base64.decode(b64, Base64.DEFAULT));
            } catch (Exception ignored) {}
        }

        // запись текста прямо в файл (UTF-8) — для больших резервных копий без сборки в памяти WebView
        // напоминания о событиях: накануне и в день
        @JavascriptInterface
        public void remind(String id, double atMillis, String title, String text, String url) {
            try { ReminderReceiver.schedule(MainActivity.this, id, (long) atMillis, title, text, url); } catch (Exception ignored) {}
        }

        @JavascriptInterface
        public void remindCancel(String id) {
            try { ReminderReceiver.cancel(MainActivity.this, id); } catch (Exception ignored) {}
        }

        // данные виджета «Ближайшее»
        @JavascriptInterface
        public void setWidget(String json) {
            try {
                getSharedPreferences("sa", MODE_PRIVATE).edit().putString("widget", json).apply();
                NextWidget.updateAll(MainActivity.this);
            } catch (Exception ignored) {}
        }

        @JavascriptInterface
        public synchronized boolean fileText(String id, String text) {
            try {
                FileOutputStream out = openFiles.get(id);
                if (out == null) return false;
                out.write(text.getBytes(java.nio.charset.StandardCharsets.UTF_8));
                return true;
            } catch (Exception e) {
                return false;
            }
        }

        @JavascriptInterface
        public synchronized void fileAbort(String id) {
            try { FileOutputStream out = openFiles.remove(id); if (out != null) out.close(); } catch (Exception ignored) {}
            File f = fileTargets.remove(id); fileMimes.remove(id);
            if (f != null) f.delete();
        }

        @JavascriptInterface
        public synchronized void fileEnd(String id, String mode, String text) {
            try {
                FileOutputStream out = openFiles.remove(id);
                if (out != null) out.close();
                final File f = fileTargets.remove(id);
                final String mime = fileMimes.remove(id);
                if (f == null) return;
                final Uri shareUri = FileProvider.getUriForFile(MainActivity.this, AUTHORITY, f);
                runOnUiThread(() -> {
                    try {
                        if ("save".equals(mode) || "saveshare".equals(mode)) {
                            try {
                                saveToDownloads(f, f.getName(), mime);
                                Toast.makeText(MainActivity.this, "Сохранено в Загрузки/SmartArts: " + f.getName(), Toast.LENGTH_LONG).show();
                            } catch (Exception e) {
                                Toast.makeText(MainActivity.this, "Не удалось сохранить в Загрузки", Toast.LENGTH_LONG).show();
                            }
                        }
                        if ("view".equals(mode)) {
                            Intent v = new Intent(Intent.ACTION_VIEW);
                            v.setDataAndType(shareUri, mime);
                            v.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                            startActivity(Intent.createChooser(v, "Открыть"));
                        } else if ("share".equals(mode) || "saveshare".equals(mode)) {
                            Intent sh = new Intent(Intent.ACTION_SEND);
                            sh.setType(mime);
                            sh.putExtra(Intent.EXTRA_STREAM, shareUri);
                            if (text != null && !text.isEmpty()) sh.putExtra(Intent.EXTRA_TEXT, text);
                            sh.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                            startActivity(Intent.createChooser(sh, "Отправить"));
                        }
                    } catch (Exception e) {
                        Toast.makeText(MainActivity.this, "Нет подходящего приложения", Toast.LENGTH_LONG).show();
                    }
                });
            } catch (Exception ignored) {}
        }

        @JavascriptInterface
        public void setBars(final String color, final boolean dark) {
            runOnUiThread(() -> {
                try {
                    int c = Color.parseColor(color);
                    Window w = getWindow();
                    w.setStatusBarColor(c);
                    w.setNavigationBarColor(c);
                    View d = w.getDecorView();
                    int flags = d.getSystemUiVisibility();
                    if (dark) flags &= ~(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
                    else flags |= View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
                    d.setSystemUiVisibility(flags);
                    web.setBackgroundColor(c);
                } catch (Exception ignored) {}
            });
        }

        @JavascriptInterface
        public void speak(String text, float rate, String id) {
            if (tts == null || !ttsReady) { js("window.__ttsDone&&window.__ttsDone(" + JSONObject.quote(id) + ")"); return; }
            tts.setSpeechRate(rate <= 0 ? 1f : rate);
            Bundle b = new Bundle();
            b.putString(TextToSpeech.Engine.KEY_PARAM_UTTERANCE_ID, id);
            tts.speak(text, TextToSpeech.QUEUE_FLUSH, b, id);
        }

        @JavascriptInterface
        public void stopSpeak() { if (tts != null) tts.stop(); }

        // HTTP-запрос из Android (без ограничений CORS у WebView) — для DeepSeek и других API
        @JavascriptInterface
        public void http(final String id, final String url, final String method, final String headersJson, final String body) {
            new Thread(() -> {
                int code;
                String text;
                HttpURLConnection c = null;
                try {
                    c = (HttpURLConnection) new URL(url).openConnection();
                    c.setRequestMethod(method == null || method.isEmpty() ? "POST" : method);
                    c.setConnectTimeout(30000);
                    c.setReadTimeout(300000);
                    JSONObject h = new JSONObject(headersJson == null || headersJson.isEmpty() ? "{}" : headersJson);
                    Iterator<String> it = h.keys();
                    while (it.hasNext()) { String k = it.next(); c.setRequestProperty(k, h.getString(k)); }
                    if (body != null && !body.isEmpty()) {
                        byte[] b = body.getBytes(StandardCharsets.UTF_8);
                        c.setDoOutput(true);
                        c.setFixedLengthStreamingMode(b.length);
                        try (OutputStream o = c.getOutputStream()) { o.write(b); }
                    }
                    code = c.getResponseCode();
                    InputStream in = code >= 400 ? c.getErrorStream() : c.getInputStream();
                    if (in == null) text = "";
                    else {
                        ByteArrayOutputStream bo = new ByteArrayOutputStream();
                        byte[] buf = new byte[16384]; int n;
                        while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
                        in.close();
                        text = new String(bo.toByteArray(), StandardCharsets.UTF_8);
                    }
                } catch (Exception e) {
                    code = -1;
                    text = String.valueOf(e.getMessage());
                } finally {
                    if (c != null) c.disconnect();
                }
                js("window.__httpDone&&window.__httpDone(" + JSONObject.quote(id) + "," + code + "," + JSONObject.quote(text) + ")");
            }).start();
        }

        @JavascriptInterface
        public void bgStart(final String text) {
            runOnUiThread(() -> {
                try {
                    if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission("android.permission.POST_NOTIFICATIONS") != PackageManager.PERMISSION_GRANTED) {
                        requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 31);
                    }
                    Intent i = new Intent(MainActivity.this, BgService.class);
                    i.putExtra("text", text);
                    startForegroundService(i);
                } catch (Exception ignored) {}
            });
        }

        @JavascriptInterface
        public void bgStop() {
            runOnUiThread(() -> { try { stopService(new Intent(MainActivity.this, BgService.class)); } catch (Exception ignored) {} });
        }

        @JavascriptInterface
        public boolean isVisible() { return visible; }

        @JavascriptInterface
        public void notifyDone(final String title, final String text) {
            if (visible) return;
            runOnUiThread(() -> {
                try {
                    BgService.ensureChannel(MainActivity.this);
                    NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
                    Notification n = new Notification.Builder(MainActivity.this, BgService.CHANNEL)
                            .setContentTitle(title)
                            .setContentText(text)
                            .setSmallIcon(android.R.drawable.stat_sys_download_done)
                            .setAutoCancel(true)
                            .setContentIntent(BgService.openApp(MainActivity.this))
                            .build();
                    if (nm != null) nm.notify(7002, n);
                } catch (Exception ignored) {}
            });
        }

        @JavascriptInterface
        public String version() {
            try { return getPackageManager().getPackageInfo(getPackageName(), 0).versionName; }
            catch (Exception e) { return ""; }
        }
    }
}
