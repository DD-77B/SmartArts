package ru.den.smartarts;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;

/** Напоминания о событиях «Хочу пойти»: накануне вечером и в день события утром. */
public class ReminderReceiver extends BroadcastReceiver {
    static final String CH = "sa_reminders";

    static void ensureChannel(Context c) {
        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm != null && nm.getNotificationChannel(CH) == null) {
            NotificationChannel ch = new NotificationChannel(CH, "Напоминания о событиях", NotificationManager.IMPORTANCE_DEFAULT);
            ch.setDescription("Выставки и концерты из «Хочу пойти»");
            nm.createNotificationChannel(ch);
        }
    }

    static PendingIntent pi(Context c, String id, String title, String text, String url) {
        Intent i = new Intent(c, ReminderReceiver.class);
        i.putExtra("id", id); i.putExtra("title", title); i.putExtra("text", text); i.putExtra("url", url);
        return PendingIntent.getBroadcast(c, id.hashCode(), i, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
    }

    static void schedule(Context c, String id, long at, String title, String text, String url) {
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        if (am == null || at < System.currentTimeMillis()) return;
        am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi(c, id, title, text, url));
    }

    static void cancel(Context c, String id) {
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        if (am != null) am.cancel(pi(c, id, "", "", ""));
    }

    @Override
    public void onReceive(Context c, Intent intent) {
        ensureChannel(c);
        String title = intent.getStringExtra("title"), text = intent.getStringExtra("text"), url = intent.getStringExtra("url");
        Intent open = new Intent(c, MainActivity.class);
        open.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        if (url != null && !url.isEmpty()) open.putExtra("open", url);
        PendingIntent p = PendingIntent.getActivity(c, (title + text).hashCode(), open, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Notification n = new Notification.Builder(c, CH)
                .setContentTitle(title == null ? "Smart Arts" : title)
                .setContentText(text == null ? "" : text)
                .setSmallIcon(android.R.drawable.ic_popup_reminder)
                .setAutoCancel(true)
                .setContentIntent(p)
                .build();
        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm != null) nm.notify(String.valueOf(intent.getStringExtra("id")).hashCode(), n);
        SharedPreferences sp = c.getSharedPreferences("sa", Context.MODE_PRIVATE);
        sp.edit().putLong("last_reminder", System.currentTimeMillis()).apply();
    }
}
