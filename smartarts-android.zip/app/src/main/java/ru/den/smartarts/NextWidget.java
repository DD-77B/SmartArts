package ru.den.smartarts;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.widget.RemoteViews;
import org.json.JSONArray;
import org.json.JSONObject;

/** Виджет «Ближайшее»: три ближайших события из Arts и Партера. Данные пишет приложение. */
public class NextWidget extends AppWidgetProvider {
    static final int[] ROWS = { R.id.w1, R.id.w2, R.id.w3 };

    static void updateAll(Context c) {
        AppWidgetManager m = AppWidgetManager.getInstance(c);
        int[] ids = m.getAppWidgetIds(new ComponentName(c, NextWidget.class));
        for (int id : ids) m.updateAppWidget(id, build(c));
    }

    static RemoteViews build(Context c) {
        RemoteViews v = new RemoteViews(c.getPackageName(), R.layout.widget_next);
        SharedPreferences sp = c.getSharedPreferences("sa", Context.MODE_PRIVATE);
        String json = sp.getString("widget", "[]");
        try {
            JSONArray a = new JSONArray(json);
            for (int i = 0; i < ROWS.length; i++) {
                if (i < a.length()) {
                    JSONObject o = a.getJSONObject(i);
                    v.setTextViewText(ROWS[i], o.optString("d") + "  " + o.optString("t") + "\n" + o.optString("p"));
                    v.setViewVisibility(ROWS[i], android.view.View.VISIBLE);
                } else {
                    v.setTextViewText(ROWS[i], i == 0 && a.length() == 0 ? "В «Хочу пойти» пока пусто" : "");
                }
            }
        } catch (Exception e) {
            v.setTextViewText(ROWS[0], "Откройте Smart Arts");
        }
        Intent open = new Intent(c, MainActivity.class);
        open.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        open.putExtra("open", "/assets/index.html?choose=1#sched");
        v.setOnClickPendingIntent(R.id.wroot, PendingIntent.getActivity(c, 77, open, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT));
        return v;
    }

    @Override
    public void onUpdate(Context c, AppWidgetManager m, int[] ids) {
        for (int id : ids) m.updateAppWidget(id, build(c));
    }
}
