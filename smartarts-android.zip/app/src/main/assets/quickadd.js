/* Smart Arts: «+» — быстро добавить мероприятие (ИИ сам решает: Arts или Партер), выход в меню, бэкап */
(function () {
  if (window.SAQuick) return;
  var p = location.pathname, cur = /\/parter\//.test(p) ? 'parter' : /\/arts\//.test(p) ? 'arts' : 'hub';
  var HUB = '/assets/index.html', ARTS = '/assets/arts/index.html', PARTER = '/assets/parter/index.html';
  // временное хранилище фото для передачи между экранами
  function tmpDb() { return new Promise(function (res, rej) { var r = indexedDB.open('sa_tmp', 1); r.onupgradeneeded = function () { r.result.createObjectStore('f', { keyPath: 'id' }); }; r.onsuccess = function () { res(r.result); }; r.onerror = function () { rej(r.error); }; }); }
  function tmpPut(id, blob, name) { return tmpDb().then(function (db) { return new Promise(function (res) { var t = db.transaction('f', 'readwrite'); t.objectStore('f').put({ id: id, blob: blob, name: name || 'photo.jpg', at: Date.now() }); t.oncomplete = function () { db.close(); res(); }; }); }); }
  function tmpTake(id) { return tmpDb().then(function (db) { return new Promise(function (res) { var t = db.transaction('f', 'readwrite'), s = t.objectStore('f'), q = s.get(id); q.onsuccess = function () { var v = q.result; s.delete(id); t.oncomplete = function () { db.close(); res(v); }; }; }); }); }
  function toDataURL(blob, max) { return new Promise(function (res) { var u = URL.createObjectURL(blob), img = new Image(); img.onload = function () { var k = Math.min(1, (max || 1400) / Math.max(img.width, img.height)), c = document.createElement('canvas'); c.width = Math.round(img.width * k); c.height = Math.round(img.height * k); c.getContext('2d').drawImage(img, 0, 0, c.width, c.height); URL.revokeObjectURL(u); res(c.toDataURL('image/jpeg', .85)); }; img.onerror = function () { res(null); }; img.src = u; }); }
  function pickPhoto() { return new Promise(function (res) { var i = document.createElement('input'); i.type = 'file'; i.accept = 'image/*'; i.onchange = function () { res(i.files[0] || null); }; i.click(); }); }
  // ИИ определяет, куда это: выставка/музей/драма → Arts, концерт/опера/балет → Партер
  function classify(dataUrl) {
    var prompt = 'Это фото афиши, билета, программки или страницы сайта о культурном мероприятии. Определи, куда его записать: ' +
      '"arts" — выставка, музей, галерея, ярмарка искусства или драматический спектакль, мюзикл; "parter" — концерт классической музыки (симфонический, камерный, сольный), опера, балет. ' +
      'Ответь ТОЛЬКО JSON: {"target":"arts или parter","what":"что это, 3–6 слов по-русски","title":"название"}';
    var key = localStorage.getItem('art_anthropic_api_key') || localStorage.getItem('pt_anthropic_key'), oa = localStorage.getItem('art_openai_key') || localStorage.getItem('pt_openai_key');
    var m = dataUrl.match(/^data:([^;]+);base64,(.*)$/), parse = function (t) { t = String(t || ''); var a = t.indexOf('{'), b = t.lastIndexOf('}'); return JSON.parse(t.slice(a, b + 1)); };
    if (key) return fetch('https://api.anthropic.com/v1/messages', { method: 'POST', headers: { 'Content-Type': 'application/json', 'x-api-key': key, 'anthropic-version': '2023-06-01', 'anthropic-dangerous-direct-browser-access': 'true' },
      body: JSON.stringify({ model: 'claude-sonnet-4-6', max_tokens: 200, messages: [{ role: 'user', content: [{ type: 'image', source: { type: 'base64', media_type: m[1], data: m[2] } }, { type: 'text', text: prompt }] }] }) })
      .then(function (r) { return r.json(); }).then(function (d) { return parse((d.content || []).map(function (b) { return b.text || ''; }).join('')); });
    if (oa) return fetch('https://api.openai.com/v1/responses', { method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + oa },
      body: JSON.stringify({ model: localStorage.getItem('pt_openai_model') || 'gpt-5.4', input: [{ role: 'user', content: [{ type: 'input_image', image_url: dataUrl }, { type: 'input_text', text: prompt }] }] }) })
      .then(function (r) { return r.json(); }).then(function (d) { var o = ''; (d.output || []).forEach(function (it) { (it.content || []).forEach(function (c) { if (c.type === 'output_text') o += c.text; }); }); return parse(o); });
    return Promise.reject(new Error('Нужен ключ Claude или ChatGPT (Настройки Smart Arts)'));
  }
  // ---- UI ----
  var css = document.createElement('style');
  css.textContent = '.saq-ov{position:fixed;inset:0;z-index:9600;background:rgba(0,0,0,.45);opacity:0;transition:opacity .2s}.saq-ov.show{opacity:1}' +
    '.saq{position:fixed;left:10px;right:10px;bottom:calc(14px + env(safe-area-inset-bottom));z-index:9601;max-width:560px;margin:0 auto;background:#14061C;border:1px solid rgba(232,200,119,.3);border-radius:22px;padding:8px;box-shadow:0 12px 40px rgba(0,0,0,.5);transform:translateY(120%);transition:transform .3s cubic-bezier(.32,.72,0,1);font:16px -apple-system,system-ui,sans-serif;color:#F3E6C4}.saq.show{transform:none}' +
    '.saq h4{font:700 14px system-ui;color:rgba(243,230,196,.6);text-transform:uppercase;letter-spacing:1px;margin:8px 12px 6px}' +
    '.saq button{display:flex;align-items:center;gap:14px;width:100%;border:0;background:none;color:inherit;text-align:left;padding:12px;border-radius:14px;font:inherit;cursor:pointer}.saq button:active{background:rgba(232,200,119,.1)}' +
    '.saq button i{font-style:normal;width:42px;height:42px;border-radius:12px;display:grid;place-items:center;font-size:21px;flex-shrink:0;background:rgba(232,200,119,.12)}.saq button b{display:block;font-weight:600}.saq button small{display:block;color:rgba(243,230,196,.55);font-size:13px;margin-top:2px}' +
    '.saq .main i{background:linear-gradient(135deg,#E8C877,#B48838);color:#2A0F38}.saq .cancel{justify-content:center;color:rgba(243,230,196,.7);font-weight:600}' +
    '.saq-hud{position:fixed;inset:0;z-index:9700;display:flex;align-items:center;justify-content:center;background:rgba(0,0,0,.4)}.saq-hud div{background:#14061C;border:1px solid rgba(232,200,119,.3);color:#F3E6C4;border-radius:16px;padding:18px 22px;font:15px system-ui;max-width:80vw;text-align:center}';
  document.head.appendChild(css);
  function sheet(title, items) {
    var ov = document.createElement('div'); ov.className = 'saq-ov'; var s = document.createElement('div'); s.className = 'saq';
    s.innerHTML = (title ? '<h4>' + title + '</h4>' : '') + items.map(function (x, i) { return '<button data-i="' + i + '" class="' + (x.main ? 'main' : '') + '"><i>' + x.ic + '</i><span><b>' + x.t + '</b>' + (x.s ? '<small>' + x.s + '</small>' : '') + '</span></button>'; }).join('') + '<button class="cancel" data-i="-1">Отменить</button>';
    var close = function () { ov.classList.remove('show'); s.classList.remove('show'); setTimeout(function () { ov.remove(); s.remove(); }, 300); };
    s.onclick = function (e) { var b = e.target.closest('[data-i]'); if (!b) return; var i = +b.dataset.i; close(); if (i >= 0 && items[i].fn) setTimeout(items[i].fn, 120); };
    ov.onclick = close; document.body.append(ov, s); requestAnimationFrame(function () { ov.classList.add('show'); s.classList.add('show'); });
  }
  function hud(t) { var h = document.createElement('div'); h.className = 'saq-hud'; h.innerHTML = '<div>' + t + '</div>'; document.body.appendChild(h); return h; }
  function go(target, hash) { var url = target === 'arts' ? ARTS : PARTER; if (cur === target && window.SAQuick && SAQuick.run) { SAQuick.run(hash); return; } location.href = url + '#' + hash; }
  async function byPhoto() {
    var f = await pickPhoto(); if (!f) return;
    var h = hud('Смотрю, что это…'), target = null, info = {};
    try { var d = await toDataURL(f, 1400); info = await classify(d); target = info.target === 'parter' ? 'parter' : 'arts'; } catch (e) { h.remove(); alert('Не удалось распознать: ' + (e.message || e)); return; }
    h.remove();
    var id = 'q' + Date.now(); await tmpPut(id, f, f.name);
    var other = target === 'arts' ? 'parter' : 'arts', L = { arts: '🏛 Arts', parter: '𝄞 Партер' };
    sheet((info.what ? info.what + (info.title ? ' — «' + info.title + '»' : '') : 'Распознано'), [
      { ic: target === 'arts' ? '🏛' : '𝄞', t: 'Добавить в ' + L[target].slice(3), s: 'ИИ определил: это ' + (target === 'arts' ? 'выставка или спектакль' : 'концерт, опера или балет'), main: true, fn: function () { go(target, 'addphoto=' + id); } },
      { ic: other === 'arts' ? '🏛' : '𝄞', t: 'Нет, в ' + L[other].slice(3), s: 'если ИИ ошибся', fn: function () { go(other, 'addphoto=' + id); } }
    ]);
  }
  function open() {
    var items = [
      { ic: '📷', t: 'По фото — ИИ сам решит куда', s: 'афиша, билет, программка: выставка → Arts, концерт/опера/балет → Партер', main: true, fn: byPhoto },
      { ic: '🏛', t: 'Выставка в Arts', s: 'заполнить вручную', fn: function () { go('arts', 'add'); } },
      { ic: '𝄞', t: 'Концерт, опера, балет в Партер', s: 'заполнить вручную', fn: function () { go('parter', 'add'); } }
    ];
    if (cur !== 'hub') items.push({ ic: '⌂', t: 'Главное меню Smart Arts', fn: function () { location.href = HUB + '?choose=1'; } });
    sheet('Добавить', items);
  }
  // выполнение в нужном приложении (по ссылке #add / #addphoto=ID)
  async function run(hash) {
    var m = String(hash || '').split('=');
    if (m[0] === 'add') { if (cur === 'arts' && typeof openExForm === 'function') { R.tab = 'ex'; R.stack = []; render(); openExForm(); } else if (cur === 'parter' && typeof openEventForm === 'function') { R.tab = 'ev'; R.stack = []; render(); openEventForm(null, { genre: R.genre !== 'all' ? R.genre : 'sym' }); } return; }
    if (m[0] === 'addphoto') {
      var rec = await tmpTake(m[1]); if (!rec) return; var file = new File([rec.blob], rec.name || 'photo.jpg', { type: rec.blob.type || 'image/jpeg' });
      var orig = window.pickFiles; window.pickFiles = function () { window.pickFiles = orig; return Promise.resolve([file]); };
      if (cur === 'parter') { R.tab = 'ev'; R.stack = []; render(); addByPhoto(); return; }
      if (cur === 'arts') { R.tab = 'ex'; R.stack = []; render(); openExForm(); setTimeout(function () { var sh = document.querySelector('.sheet.show [data-pick]') || document.querySelector('[data-pick]'); if (sh) sh.click(); setTimeout(function () { var rc = document.querySelector('[data-rec]'); if (rc) rc.click(); }, 900); }, 450); }
    }
  }
  window.SAQuick = { open: open, run: run, byPhoto: byPhoto };
})();
