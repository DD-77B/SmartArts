/* Smart Arts: вибрация на нажатия — как в SWS. Настройки: Smart Arts → Настройки → «Вибрация». */
(function () {
  if (window.SAHaptic) return;
  var LV = { 1: { tap: 8, amp: 70 }, 2: { tap: 14, amp: 150 }, 3: { tap: 24, amp: 255 } };
  function cfg() { var c = {}; try { c = JSON.parse(localStorage.getItem('sa_vibro') || '{}') || {}; } catch (e) {} return { on: c.on !== false, lvl: c.lvl || 2, btn: c.btn !== false, tab: c.tab !== false, star: c.star !== false, done: c.done !== false }; }
  var last = 0;
  function buzz(kind, force) {
    var c = cfg(); if (!c.on && !force) return;
    if (!force && ((kind === 'tap' && !c.btn) || ((kind === 'tab' || kind === 'tick') && !c.tab) || (kind === 'star' && !c.star) || ((kind === 'done' || kind === 'error') && !c.done))) return;
    var now = Date.now(); if (!force && now - last < 35 && kind !== 'done' && kind !== 'error') return; last = now;
    var L = LV[c.lvl] || LV[2], t = L.tap, P;
    if (kind === 'tab') P = [Math.round(t * 1.3)];
    else if (kind === 'tick') P = [Math.max(5, Math.round(t * .7))];
    else if (kind === 'star') P = [t, 45, t];
    else if (kind === 'done') P = [t * 2, 70, t * 2];
    else if (kind === 'error') P = [t * 3, 60, t * 3, 60, t * 3];
    else P = [t];
    try { if (window.AndroidBridge && AndroidBridge.vibrate) { AndroidBridge.vibrate(P.join(','), L.amp); return; } } catch (e) {}
    try { if (navigator.vibrate) navigator.vibrate(P); } catch (e) {}
  }
  window.SAHaptic = { buzz: buzz, cfg: cfg, set: function (k, v) { var c = cfg(); c[k] = v; localStorage.setItem('sa_vibro', JSON.stringify(c)); } };
  // отклик на любое нажатие по кнопкам, строкам, вкладкам, переключателям и звёздам
  document.addEventListener('pointerdown', function (e) {
    var el = e.target.closest && e.target.closest('button, a[href], [onclick], .row, .tab, .chip, .acc-h, .acc-o, select, input[type=checkbox], label.field, .ev, .tile, .seg button, .stars button');
    if (!el || el.disabled || el.classList.contains('nohl') || el.matches('input[type=text], textarea')) return;
    var kind = el.closest('.stars') ? 'star' : el.closest('.tabbar, .tab-bar, .menu, #sa-top, nav') ? 'tab' : el.closest('.seg, .chips, .genres, .acc-b') || el.matches('input[type=checkbox], select') ? 'tick' : 'tap';
    buzz(kind);
  }, { capture: true, passive: true });
  // «готово» и ошибки: тосты об успехе и окна ошибок
  function wrap() {
    if (typeof window.toast === 'function' && !window.toast.__sa) { var t0 = window.toast; window.toast = function (m) { if (/готов|сохран|добавлен|найдено|восстановлен/i.test(String(m || ''))) buzz('done'); return t0.apply(this, arguments); }; window.toast.__sa = 1; }
    if (typeof window.alertBox === 'function' && !window.alertBox.__sa) { var a0 = window.alertBox; window.alertBox = function (o) { if (o && /не удалось|ошибк|не получилось|нет связи/i.test(String(o.title || '') + ' ' + String(o.msg || ''))) buzz('error'); return a0.apply(this, arguments); }; window.alertBox.__sa = 1; }
  }
  if (document.readyState !== 'loading') setTimeout(wrap, 0); else document.addEventListener('DOMContentLoaded', function () { setTimeout(wrap, 0); });
})();
