/* Smart Arts: плавающая «A» внутри приложений + переходы по ссылкам из хаба */
(function () {
  var p = location.pathname, cur = /\/parter\//.test(p) ? 'parter' : /\/arts\//.test(p) ? 'arts' : 'hub';
  var HUB = '/assets/index.html';
  var APPS = { arts: { href: '/assets/arts/index.html', label: 'Arts', ic: '🏛' }, parter: { href: '/assets/parter/index.html', label: 'Партер', ic: '𝄞' } };
  try { if (cur !== 'hub') localStorage.setItem('sa_last', cur); } catch (e) {}
  window.SA = { app: cur, hub: function (h) { location.href = HUB + '?choose=1' + (h ? '#' + h : ''); } };
  if (cur === 'hub') return;
  // ---- переход из хаба: #ex=ID, #ev=ID, #guide=KEY, #more, #backup ----
  function deep() {
    var h = decodeURIComponent(location.hash.slice(1)); if (!h) return;
    var tries = 0, t = setInterval(function () {
      tries++;
      var ready = cur === 'arts' ? (typeof S !== 'undefined' && S.exhibitions && typeof go === 'function' && document.querySelector('#app *')) : (typeof S !== 'undefined' && S.events && typeof go === 'function' && document.querySelector('#app *'));
      if (!ready && tries < 60) return; clearInterval(t); if (!ready) return;
      try {
        var m = h.split('=');
        if (m[0] === 'ex' && cur === 'arts') { R.tab = 'ex'; R.stack = []; go('ex', m[1]); }
        else if (m[0] === 'guide' && cur === 'arts') { R.tab = 'guides'; R.stack = []; go('guide', m.slice(1).join('=')); }
        else if (m[0] === 'guides' && cur === 'arts') setTab('guides');
        else if (m[0] === 'ticket' && cur === 'arts') { setTab('more'); setTimeout(function () { if (typeof openTicket === 'function') { if (typeof loadTickets === 'function') loadTickets().then(function () { openTicket(m[1]); }); else openTicket(m[1]); } }, 300); }
        else if (m[0] === 'ev' && cur === 'parter') { R.tab = 'ev'; R.stack = []; go('ev', m[1]); }
        else if (m[0] === 'more') setTab('more');
        else if (m[0] === 'backup') { setTab('more'); setTimeout(function () { if (typeof exportData === 'function') exportData(); }, 400); }
      } catch (e) {}
      history.replaceState(null, '', location.pathname);
    }, 150);
  }
  // ---- плавающая кнопка ----
  var KEY = 'sa_switch_pos', box, open;
  function loadPos() { try { var v = JSON.parse(localStorage.getItem(KEY) || 'null'); if (v && (v.s === 'l' || v.s === 'r') && v.y >= 0 && v.y <= 1) return v; } catch (e) {} return { s: 'l', y: 0.80 }; }
  function mount() {
    if (document.getElementById('sa-switch')) return;
    var css = document.createElement('style');
    css.textContent =
      '#sa-switch{position:fixed;z-index:8000;width:48px;height:48px;touch-action:none;font:600 15px -apple-system,system-ui,sans-serif;transition:opacity .25s}' +
      '#sa-switch .safab{width:48px;height:48px;border-radius:50%;border:0;padding:0;display:grid;place-items:center;cursor:pointer;font:700 22px Georgia,serif;color:#F3DFA2;background:radial-gradient(circle at 35% 30%,#5C2275,#2A0F38);box-shadow:0 4px 14px rgba(42,15,56,.45),inset 0 0 0 1.5px rgba(232,200,119,.55);transition:transform .15s}' +
      '#sa-switch.idle{opacity:.55}#sa-switch.drag .safab{transform:scale(1.12)}' +
      '#sa-switch .samenu{position:absolute;display:none;flex-direction:column;gap:6px;min-width:200px}#sa-switch.open .samenu{display:flex}' +
      '#sa-switch .samenu a{display:flex;align-items:center;gap:10px;padding:10px 14px;border-radius:16px;text-decoration:none;color:#2A0F38;white-space:nowrap;background:rgba(255,255,255,.95);box-shadow:0 4px 14px rgba(0,0,0,.18)}' +
      '#sa-switch .samenu a i{font-style:normal;font-size:19px;width:24px;display:grid;place-items:center}#sa-switch .samenu a.cur{opacity:.45;pointer-events:none}' +
      'html[data-theme=dark] #sa-switch .samenu a{background:rgba(44,30,52,.96);color:#F3E6C4}#sa-switch.hid{display:none}';
    document.head.appendChild(css);
    box = document.createElement('div'); box.id = 'sa-switch'; box.className = 'idle';
    box.innerHTML = '<div class="samenu"><a href="' + HUB + '?choose=1"><i>⌂</i>Smart Arts</a>' +
      Object.keys(APPS).map(function (k) { return '<a href="' + APPS[k].href + '"' + (k === cur ? ' class="cur"' : '') + '><i>' + APPS[k].ic + '</i>' + APPS[k].label + '</a>'; }).join('') +
      '<a href="' + HUB + '?choose=1#sched"><i>📅</i>Хочу пойти</a></div><button class="safab" aria-label="Smart Arts">A</button>';
    document.documentElement.appendChild(box);
    setInterval(function () { box.classList.toggle('hid', !!document.querySelector('.sheet.show,.alert-bg,.asheet,.overlay.show,.pv,#spk.show,.spk.show')); }, 400);
    var fab = box.querySelector('.safab'), menu = box.querySelector('.samenu'), pos = loadPos(), idleT = 0, closeT = 0;
    function place() { var H = innerHeight, W = innerWidth, top = Math.max(8, Math.min(H - 56, pos.y * H - 24)); box.style.top = top + 'px'; box.style.left = pos.s === 'l' ? '8px' : (W - 56) + 'px'; var up = top > H / 2; menu.style.left = pos.s === 'l' ? '0' : ''; menu.style.right = pos.s === 'r' ? '0' : ''; menu.style.bottom = up ? '56px' : ''; menu.style.top = up ? '' : '56px'; menu.style.flexDirection = up ? 'column-reverse' : 'column'; }
    function setIdle() { clearTimeout(idleT); box.classList.remove('idle'); idleT = setTimeout(function () { if (!box.classList.contains('open')) box.classList.add('idle'); }, 2500); }
    open = function (v) { box.classList.toggle('open', v); clearTimeout(closeT); if (v) { box.classList.remove('idle'); closeT = setTimeout(function () { open(false); }, 6000); } else setIdle(); };
    place(); addEventListener('resize', place);
    var sx = 0, sy = 0, moved = false, dragging = false;
    fab.addEventListener('pointerdown', function (e) { dragging = true; moved = false; sx = e.clientX; sy = e.clientY; try { fab.setPointerCapture(e.pointerId); } catch (x) {} setIdle(); });
    fab.addEventListener('pointermove', function (e) { if (!dragging) return; if (!moved && Math.abs(e.clientX - sx) + Math.abs(e.clientY - sy) < 8) return; if (!moved) { moved = true; open(false); box.classList.add('drag'); } box.style.left = Math.max(4, Math.min(innerWidth - 52, e.clientX - 24)) + 'px'; box.style.top = Math.max(4, Math.min(innerHeight - 52, e.clientY - 24)) + 'px'; });
    function end(e) { if (!dragging) return; dragging = false; box.classList.remove('drag'); if (moved) { pos = { s: e.clientX < innerWidth / 2 ? 'l' : 'r', y: Math.max(.05, Math.min(.95, e.clientY / innerHeight)) }; try { localStorage.setItem(KEY, JSON.stringify(pos)); } catch (x) {} place(); setIdle(); } else open(!box.classList.contains('open')); }
    fab.addEventListener('pointerup', end); fab.addEventListener('pointercancel', end);
    document.addEventListener('pointerdown', function (e) { if (box.classList.contains('open') && !box.contains(e.target)) open(false); }, true);
    setIdle();
  }
  function wrapBack() { var orig = window.androidBack; window.androidBack = function () { if (box && box.classList.contains('open')) { open(false); return true; } if (orig && orig()) return true; window.SA.hub(); return true; }; }
  function init() { mount(); wrapBack(); deep(); }
  if (document.readyState !== 'loading') setTimeout(init, 0); else document.addEventListener('DOMContentLoaded', function () { setTimeout(init, 0); });
})();
