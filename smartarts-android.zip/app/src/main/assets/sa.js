/* Smart Arts: плавающая «A» внутри приложений + переходы по ссылкам из хаба */
(function () {
  var p = location.pathname, cur = /\/parter\//.test(p) ? 'parter' : /\/arts\//.test(p) ? 'arts' : 'hub';
  var HUB = '/assets/index.html';
  var APPS = { arts: { href: '/assets/arts/index.html', label: 'Arts', ic: '🏛' }, parter: { href: '/assets/parter/index.html', label: 'Партер', ic: '𝄞' } };
  try { if (cur !== 'hub') localStorage.setItem('sa_last', cur); } catch (e) {}
  window.SA = { app: cur, hub: function (h) { location.href = HUB + '?choose=1' + (h ? '#' + h : ''); } };
  if (cur === 'hub') return;
  // ---- переход из хаба: #ex=ID, #ev=ID, #guide=KEY, #more, #backup ----
  function deep() {
    var h = decodeURIComponent(location.hash.slice(1)); if (!h) return;
    var tries = 0, t = setInterval(function () {
      tries++;
      var ready = cur === 'arts' ? (typeof S !== 'undefined' && S.exhibitions && typeof go === 'function' && document.querySelector('#app *')) : (typeof S !== 'undefined' && S.events && typeof go === 'function' && document.querySelector('#app *'));
      if (!ready && tries < 60) return; clearInterval(t); if (!ready) return;
      try {
        var m = h.split('=');
        if (m[0] === 'ex' && cur === 'arts') { R.tab = 'ex'; R.stack = []; go('ex', m[1]); }
        else if (m[0] === 'guide' && cur === 'arts') { R.tab = 'guides'; R.stack = []; go('guide', m.slice(1).join('=')); }
        else if (m[0] === 'guides' && cur === 'arts') setTab('guides');
        else if (m[0] === 'ticket' && cur === 'arts') { setTab('more'); setTimeout(function () { if (typeof openTicket === 'function') { if (typeof loadTickets === 'function') loadTickets().then(function () { openTicket(m[1]); }); else openTicket(m[1]); } }, 300); }
        else if (m[0] === 'ev' && cur === 'parter') { R.tab = 'ev'; R.stack = []; go('ev', m[1]); }
        else if (m[0] === 'more') setTab('more');
        else if (m[0] === 'backup') { setTab('more'); setTimeout(function () { if (typeof exportData === 'function') exportData(); }, 400); }
      } catch (e) {}
      history.replaceState(null, '', location.pathname);
    }, 150);
  }
  // ---- верхняя панель Smart Arts: возврат в меню и переход между приложениями ----
  var THEME_ON = localStorage.getItem('sa_theme') !== '0';
  function mount() {
    if (document.getElementById('sa-top')) return;
    var tint = cur === 'parter' ? '#E8799A' : '#E8C877';
    var css = document.createElement('style');
    css.textContent =
      ':root{--sa-top:50px}' +
      '#sa-top{position:fixed;left:0;right:0;top:0;z-index:9000;padding-top:env(safe-area-inset-top);background:rgba(12,3,17,.97);-webkit-backdrop-filter:blur(14px);backdrop-filter:blur(14px);border-bottom:1px solid rgba(232,200,119,.22)}' +
      '#sa-top .in{max-width:640px;margin:0 auto;height:50px;display:flex;align-items:center;gap:6px;padding:0 10px}' +
      '#sa-top button{border:0;background:none;color:rgba(243,230,196,.7);font:600 15px -apple-system,system-ui,sans-serif;display:flex;align-items:center;gap:6px;padding:8px 11px;border-radius:16px;cursor:pointer;white-space:nowrap}' +
      '#sa-top button.cur{background:rgba(232,200,119,.14);color:' + tint + '}' +
      '#sa-top .home{margin-right:auto;color:#E8C877;font:700 17px Georgia,serif;padding-left:2px}#sa-top .em{font-size:20px;line-height:1}' +
      '#sa-top .home b{display:inline-grid;place-items:center;width:34px;height:34px;border-radius:9px;background:linear-gradient(135deg,#4E1A64,#26092F);box-shadow:inset 0 0 0 1px rgba(232,200,119,.45);font:700 14px Georgia,serif;color:#E8C877}' +
      'body{padding-top:calc(var(--sa-top) + env(safe-area-inset-top)) !important}' +
      '.navbar{top:calc(var(--sa-top) + env(safe-area-inset-top)) !important;padding-top:0 !important;height:46px !important}';
    document.head.appendChild(css);
    var bar = document.createElement('div'); bar.id = 'sa-top';
    bar.innerHTML = '<div class="in"><button class="home" data-go="' + HUB + '?choose=1"><b>SA</b>Smart Arts</button>' +
      '<button data-go="' + APPS.arts.href + '"' + (cur === 'arts' ? ' class="cur"' : '') + '><span class="em">🏛</span>Arts</button>' +
      '<button data-go="' + APPS.parter.href + '"' + (cur === 'parter' ? ' class="cur"' : '') + '><span class="em">𝄞</span>Партер</button>' +
      '<button data-go="' + HUB + '?choose=1#sched" aria-label="Хочу пойти"><span class="em">📅</span></button></div>';
    // кнопки, а не ссылки: приложения перехватывают ссылки и открывают их во внешнем браузере
    bar.addEventListener('click', function (e) { var b = e.target.closest('[data-go]'); if (!b) return; e.preventDefault(); e.stopPropagation(); if (b.classList.contains('cur')) { window.scrollTo({ top: 0, behavior: 'smooth' }); return; } location.href = b.dataset.go; }, true);
    document.documentElement.appendChild(bar);
    if (THEME_ON) applySaTheme(tint);
  }
  // ---- фирменная тема: пурпурный фон как у иконки; Arts — золото, Партер — розовый ----
  function applySaTheme(tint) {
    var V = '--bg:#12051A;--cell:#200C2C;--sheetbg:#170720;--sheetcell:#261034;--label:#F3E6C4;--label2:rgba(243,230,196,.62);--label3:rgba(243,230,196,.32);' +
      '--sep:rgba(232,200,119,.18);--fill:rgba(232,200,119,.12);--fill2:rgba(232,200,119,.2);--hl:#331A40;--bar:rgba(16,5,23,.94);--segon:#41205A;--asbg:rgba(34,13,46,.97);--swoff:#331A40;--gold:#E8C877;--tint:' + tint;
    var css = document.createElement('style'); css.id = 'sa-theme';
    css.textContent = 'html.sa-th,html.sa-th[data-theme],html.sa-th[data-theme=dark],html.sa-th[data-theme=light]{' + V.split(';').map(function (x) { return x + ' !important'; }).join(';') + '}' +
      'html.sa-th,html.sa-th body{background:linear-gradient(170deg,#1E0A29 0%,#12051A 55%,#0A0310 100%) fixed #0A0310 !important;color:#F3E6C4}' +
      'html.sa-th .large-title,html.sa-th .d-title{color:' + tint + '}' +
      'html.sa-th .tabbar,html.sa-th .tab-bar{background:rgba(12,3,17,.96) !important;border-top-color:rgba(232,200,119,.2) !important}' +
      'html.sa-th input,html.sa-th textarea,html.sa-th select{color:#F3E6C4}';
    document.head.appendChild(css);
    document.documentElement.classList.add('sa-th');
    if (window.AndroidBridge && AndroidBridge.setBars) try { AndroidBridge.setBars('#0C0311', true); } catch (e) {}
  }
  function wrapBack() { var orig = window.androidBack; window.androidBack = function () { if (orig && orig()) return true; window.SA.hub(); return true; }; }
  function init() { mount(); wrapBack(); deep(); }
  if (document.readyState !== 'loading') setTimeout(init, 0); else document.addEventListener('DOMContentLoaded', function () { setTimeout(init, 0); });
})();
